package com.example.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.regex.Pattern

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        supportActionBar?.hide()
        var eti = findViewById<EditText>(R.id.editTextName1)
        var pass1 = findViewById<EditText>(R.id.editTextPassword3)
        var pass2 = findViewById<EditText>(R.id.editTextPassword1)
        var reg = findViewById<Button>(R.id.cirRegisterButton)
       // var co = findViewById<TextView>(R.id.ConfirmPassAlert)
        val sharedPrefFile = "kotlinsharedpreference"
        val sharedPreferences: SharedPreferences = this.getSharedPreferences(
            sharedPrefFile,
            Context.MODE_PRIVATE
        )

            reg.setOnClickListener {

                if (eti.text.isBlank() || pass1.text.isBlank() || pass2.text.isBlank()) {
                    if(eti.text.isBlank()){
                        eti.setError("please fill out all required fields")
                    }
                    if(pass1.text.isBlank()){
                        pass1.setError("please fill out all required fields")
                    }
                    if(pass2.text.isBlank()){
                        pass2.setError("please fill out all required fields")
                    }

                } else {
                    var i = readData(eti.text.toString())
                    /*if (i == -1) {
                        if (!(pass1.text.toString().equals(pass2.text.toString()))) {
                            pass2.setError("password and confirm password didn't match")

                        } else {
                            GlobalVariable.name=eti.text.toString()
                            saveFireStore(eti.text.toString(),pass1.text.toString())
                            val intent = Intent(this, DisplayDetailsActivity::class.java)
                            //var eti = findViewById<EditText>(R.id.editTextName1)
                            //intent.putExtra("msg_key",eti.text.toString())
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        eti.setText("")
                        pass1.setText("")
                        pass2.setText("")
                        eti.setError("Username is already taken, please enter a new one")
                    }*/
                }
            }
    }
    fun saveFireStore(name:String,password:String) {
        var userobject:Userdetails= Userdetails(password)
        var d: FirebaseDatabase = FirebaseDatabase.getInstance()
        var node: DatabaseReference =d.getReference("users/$name")
        node.child("Userdetails").setValue(userobject)
    }
    private fun readData(userName: String):Int {
        var eti = findViewById<EditText>(R.id.editTextName1)
       //var database = FirebaseDatabase.getInstance().getReference("users/$userName")
        var pass1 = findViewById<EditText>(R.id.editTextPassword3)
        var pass2 = findViewById<EditText>(R.id.editTextPassword1)
        var i=-1
        var d: FirebaseDatabase = FirebaseDatabase.getInstance()
        var node: DatabaseReference =d.getReference("users/${userName.toString()}")
      //  node.child("Userdetails").setValue(userobject)
        node.get().addOnSuccessListener {
            if (it.exists()){
                eti.setText("")
                pass1.setText("")
                pass2.setText("")
                eti.setError("Username is already taken, please enter a new one")
            }else{
                if (!(pass1.text.toString().equals(pass2.text.toString()))) {
                    pass2.setError("password and confirm password didn't match")
                }
                else if(isValidPassword(pass1.text.toString())){
                    GlobalVariable.name=userName.toString()
                    saveFireStore(userName.toString(),pass1.text.toString())
                    val intent = Intent(this, DisplayDetailsActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }
        return i
    }
    fun isValidPassword(password: String): Boolean {
        val str = password
        var valid = true
        if (str.length < 8) {
            valid = false
            findViewById<EditText>(R.id.editTextPassword1).setError("Password should be minimum minimum 8 characters long")
        }
        var exp = ".*[0-9].*"
        var pattern = Pattern.compile(exp, Pattern.CASE_INSENSITIVE)
        var matcher = pattern.matcher(str)
        if (!matcher.matches()) {
            valid = false
            findViewById<EditText>(R.id.editTextPassword1).setError("Password should contain at least one number")
        }
        exp = ".*[A-Z].*"
        pattern = Pattern.compile(exp)
        matcher = pattern.matcher(str)
        if (!matcher.matches()) {
            valid = false
            findViewById<EditText>(R.id.editTextPassword1).setError("Password should contain at least one capital letter")
        }
        exp = ".*[~!@#\$%\\^&*()\\-_=+\\|\\[{\\]};:'\",<.>/?].*"
        pattern = Pattern.compile(exp)
        matcher = pattern.matcher(str)
        if (!matcher.matches()) {
            valid = false
            findViewById<EditText>(R.id.editTextPassword1).setError("Password should contain at least one special character")
        }

        return valid
    }
    override fun onBackPressed() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    fun onLoginClick(view: View) {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

}