package com.example.app

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DisplayDetailsActivity : AppCompatActivity() {
       // val strname: String = intent.getStringExtra("msg_key").toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_details)
        supportActionBar?.hide()
        var intent = Intent()


        // Capture the layout's TextView and set the string as its text
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        val viewPager2 = findViewById<ViewPager2>(R.id.viewpager2)
       // idicator.setViewPager(viewPager2)
        //viewPager1.adapter=pageadapter(supportFragmentManager)
        val layout1 = findViewById<TabLayout>(R.id.talayout)
        val adapter=pageAdapter(supportFragmentManager,lifecycle)

        viewPager2.adapter=adapter

        TabLayoutMediator(layout1, viewPager2){ tab, position->
            when(position){
                0->{
                    tab.text="Personal"
                }
                1->{
                    tab.text="education"
                }
                2->{
                    tab.text="Financial"
                }
                3->{
                    tab.text="Family"
                }
            }
        }.attach()

      /*  var co=findViewById<EditText>(R.id.eTco)
        var countryCodeValue = ""
        val localCountry = Locale.getDefault()

        countryCodeValue = localCountry.displayCountry
        if(countryCodeValue.equals("India")){
            co.text.insert(co.selectionStart,"+91")
        }*/

    }

    override fun onBackPressed() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
    }
