package com.example.app

class Family {
    lateinit var mothername:String
    lateinit var fathername:String

    constructor(mothername: String, fathername: String, siblings: String, spousename: String) {
        this.mothername = mothername
        this.fathername = fathername
        this.siblings = siblings
        this.spousename = spousename
    }

    lateinit var siblings:String
    lateinit var spousename:String
}