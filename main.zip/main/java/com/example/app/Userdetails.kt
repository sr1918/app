package com.example.app

class Userdetails {
    lateinit var password:String

    constructor( password: String) {
        this.password = password
    }

}