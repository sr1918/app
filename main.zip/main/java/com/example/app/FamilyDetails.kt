package com.example.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


@Suppress("UNREACHABLE_CODE")
class FamilyDetails : Fragment() {
    private lateinit var seterrormothername:TextView
    private lateinit var seterrorfathername:TextView
    private var isvalidadname=false
    private var isvalidmomname=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_family_details, container, false)
        view.findViewById<EditText>(R.id.eTmom).addTextChangedListener(textWatcher)
        view.findViewById<EditText>(R.id.eTdad).addTextChangedListener(textWatcher1)
        view.findViewById<TextView>(R.id.validmothername).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<TextView>(R.id.validfathername).setTextColor(Color.parseColor("#FF0000"))
        seterrormothername=view.findViewById<TextView>(R.id.validmothername)
        seterrorfathername=view.findViewById<TextView>(R.id.validfathername)
        view?.findViewById<Button>(R.id.prev4)?.setOnClickListener {
            val viewpager=activity?.findViewById<ViewPager2>(R.id.viewpager2)
            viewpager?.currentItem=2
        }
        view?.findViewById<Button>(R.id.submit)?.setOnClickListener {
            //  var d:DisplayDetailsActivity=DisplayDetailsActivity()
            if(isvalid(view.findViewById<EditText>(R.id.eTmom).text.toString(),
                    view.findViewById<EditText>(R.id.eTdad).text.toString() )) {
                saveFireStore(
                    view.findViewById<EditText>(R.id.eTmom).text.toString(),
                    view.findViewById<EditText>(R.id.eTdad).text.toString(),
                    view.findViewById<EditText>(R.id.eTsi).text.toString(),
                    view.findViewById<EditText>(R.id.eTsp).text.toString()
                )
                val i = Intent(activity, LoginActivity::class.java)
                startActivity(i)
                activity?.finish()
            }
        }
        return view
    }
    val textWatcher = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrormothername.setText("Field can't be empty")
                seterrormothername.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrormothername.setText("Perfect")
                seterrormothername.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }
    val textWatcher1 = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorfathername.setText("Field can't be empty")
                seterrorfathername.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorfathername.setText("Perfect")
                seterrorfathername.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }
    fun saveFireStore(mothername: String, fathername: String, siblingname: String,spousename:String) {
        var name:String=GlobalVariable.name
        var userobject:Family= Family(mothername,fathername,siblingname,spousename)
        var d: FirebaseDatabase = FirebaseDatabase.getInstance()
        var node: DatabaseReference =d.getReference("users/$name")
        node.child("family").setValue(userobject)
    }
    fun isvalid(momname:String,dadname: String):Boolean{
        var isvalidmom=momname.isNotEmpty()
        var isvaliddad=dadname.isNotEmpty()
        return isvalidmom&&isvaliddad
    }
}