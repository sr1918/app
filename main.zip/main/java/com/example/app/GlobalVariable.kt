package com.example.app

class GlobalVariable {

    companion object {
        var name :String=""

    }
}