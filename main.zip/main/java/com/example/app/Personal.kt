package com.example.app

class Personal {
    lateinit var fullname:String
    lateinit var contact:String
    lateinit var bio:String
    lateinit var hobbies:String
    lateinit var gender:String

    constructor(fullname: String, contact: String, hobbies: String,bio: String, gender: String) {
        this.fullname = fullname
        this.contact = contact
        this.bio = bio
        this.hobbies = hobbies
        this.gender = gender
    }
}