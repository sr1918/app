package com.example.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FinancialDetails.newInstance] factory method to
 * create an instance of this fragment.
 */
@Suppress("UNREACHABLE_CODE")
class FinancialDetails : Fragment() {
    private lateinit var seterrorctc: TextView
    private lateinit var seterrorsal: TextView
    private var isvalidctc=false
    private var isvalidsal=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @SuppressLint("CutPasteId")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_financial_details, container, false)
        view.findViewById<TextView>(R.id.validctc).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<TextView>(R.id.validsal).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<EditText>(R.id.eTctc).addTextChangedListener(textWatcher)
        view.findViewById<EditText>(R.id.eTsal).addTextChangedListener(textWatcher1)
        seterrorctc=view.findViewById<TextView>(R.id.validctc)
        seterrorsal=view.findViewById<TextView>(R.id.validsal)
        view?.findViewById<Button>(R.id.prev3)?.setOnClickListener {
            val viewpager = activity?.findViewById<ViewPager2>(R.id.viewpager2)
            viewpager?.currentItem = 1
        }
        view?.findViewById<Button>(R.id.next3)?.setOnClickListener {

          //  var d:DisplayDetailsActivity=DisplayDetailsActivity()
            if(isvalid(view.findViewById<EditText>(R.id.eTsal).text.toString(),
                    view.findViewById<EditText>(R.id.eTctc).text.toString() )) {
                saveFireStore(
                    view.findViewById<EditText>(R.id.eTsal).text.toString(),
                    view.findViewById<EditText>(R.id.eTit).text.toString(),
                    view.findViewById<EditText>(R.id.eTctc).text.toString(),
                    // d.strname
                )
                val viewpager = activity?.findViewById<ViewPager2>(R.id.viewpager2)
                viewpager?.currentItem = 3
            }
        }
        return view
    }
    val textWatcher = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorctc.setText("Field can't be empty")
                seterrorctc.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorctc.setText("Perfect")
                seterrorctc.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }
    val textWatcher1 = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorsal.setText("Field can't be empty")
                seterrorsal.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorsal.setText("Perfect")
                seterrorsal.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }
    fun saveFireStore(sal: String, itax: String, ctc: String) {
        var name:String=GlobalVariable.name
    var userobject:Financial= Financial(ctc,itax,sal)
    var d:FirebaseDatabase= FirebaseDatabase.getInstance()
        var node:DatabaseReference=d.getReference("users/$name")
        node.child("financial").setValue(userobject)
    }
    fun isvalid(salary:String,ctc: String):Boolean{
        var isvalidsal=salary.isNotEmpty()
        var isvalidctc=ctc.isNotEmpty()
        return isvalidsal&&isvalidctc
    }
}


