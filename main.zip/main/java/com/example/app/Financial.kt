package com.example.app

class Financial {
    lateinit var ctc:String
    lateinit var salary:String
    lateinit var incometax:String

    constructor(ctc: String, incometax: String,salary: String) {
        this.ctc = ctc
        this.salary = salary
        this.incometax = incometax
    }
}