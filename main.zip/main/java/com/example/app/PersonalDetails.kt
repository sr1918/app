package com.example.app


import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [PersonalDetails.newInstance] factory method to
 * create an instance of this fragment.
 */
@Suppress("UNREACHABLE_CODE")
class PersonalDetails : Fragment() {

    var cal = Calendar.getInstance()
    private var isvalidco=false
    private var isvalidfname=false
    private lateinit var seterrorco:TextView
    private lateinit var seterrorfname:TextView
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



       // datePickerDialog.show(fragmentManager,"")
       /* val dateSetListener = object : DatePickerDialog.OnDateSetListener {
            override fun onDateSet(view: DatePicker, year: Int, monthOfYear: Int,
                                   dayOfMonth: Int) {
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDateInView()
            }
        }*/


        // when you click on the button, show DatePickerDialog that is set with OnDateSetListener


    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment


        val view= inflater.inflate(R.layout.fragment_personal_details, container, false)
        view.findViewById<TextView>(R.id.validco).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<TextView>(R.id.validfname).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<EditText>(R.id.eTco).addTextChangedListener(textWatcher)
        view.findViewById<EditText>(R.id.eTname).addTextChangedListener(textWatcher1)
        seterrorfname=view.findViewById<TextView>(R.id.validfname)
        seterrorco=view.findViewById<TextView>(R.id.validco)
       // view.findViewById<EditText>(R.id.eTname).addTextChangedListener(logintextwatcher)
        //view?.findViewById<EditText>(R.id.eTco)!!.addTextChangedListener(logintextwatcher)
        //view?.findViewById<EditText>(R.id.groupradio)!!.addTextChangedListener(logintextwatcher)
        view?.findViewById<Button>(R.id.next)?.setOnClickListener {

        }

        view?.findViewById<Button>(R.id.next)?.setOnClickListener {
            var i=view.findViewById<RadioGroup>(R.id.groupradio).checkedRadioButtonId
            var c=view.findViewById<RadioButton>(i).text.toString()
          //  Toast.makeText(activity,validcount,Toast.LENGTH_SHORT).show()
            if(isvalid(view.findViewById<EditText>(R.id.eTname).text.toString(),
                    view.findViewById<EditText>(R.id.eTco).text.toString())) {
                saveFireStore(
                    view.findViewById<EditText>(R.id.eTname).text.toString(),
                    view.findViewById<EditText>(R.id.eTco).text.toString(),
                    view.findViewById<EditText>(R.id.eTho).text.toString(),
                    view.findViewById<EditText>(R.id.eTbio).text.toString(),
                    c
                    // d.strname
                )
                val viewpager = activity?.findViewById<ViewPager2>(R.id.viewpager2)
                viewpager?.currentItem = 1
            }

        }



        //var d:DisplayDetailsActivity=DisplayDetailsActivity()
        return view
    }
    val textWatcher = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length!=10){
                seterrorco.setText("Enter 10 digits")
                seterrorco.setTextColor(Color.parseColor("#FF0000"))
            }
            if(s?.length==10){
                seterrorco.setText("Perfect")
                seterrorco.setTextColor(Color.parseColor("#28DC30"))

            }
        }
    }
    val textWatcher1 = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorfname.setText("Field can't be empty")
                seterrorfname.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorfname.setText("Perfect")
                seterrorfname.setTextColor(Color.parseColor("#28DC30"))

            }
        }
    }

    /* private fun updateDateInView() {
         val myFormat = "MM/dd/yyyy" // mention the format you need
         val sdf = SimpleDateFormat(myFormat, Locale.US)
         var log =requireView().findViewById<TextView>(R.id.eThobs)
         log!!.text = sdf.format(cal.getTime())
     }*/
   fun saveFireStore(Fullname: String, contact: String, hobbies: String,bio:String,gender:String) {
       var name:String=GlobalVariable.name
       var userobject:Personal= Personal(Fullname,contact,hobbies,bio,gender)
       var d: FirebaseDatabase = FirebaseDatabase.getInstance()
       var node: DatabaseReference =d.getReference("users/$name")
       node.child("personal").setValue(userobject)
   }
    fun isvalid(fullname:String,contact: String):Boolean{
        var isvalidfname=fullname.isNotEmpty()
        var isvalidco=contact.isNotEmpty()&&contact.length==10
        return isvalidco&&isvalidfname
    }


}