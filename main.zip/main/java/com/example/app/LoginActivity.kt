package com.example.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase


class LoginActivity : AppCompatActivity() {
    val SHARED_PREFS = "shared_prefs"


    // key for storing email.


    // key for storing email.
    val USER_KEY = "user_key"

    val PASSWORD_KEY = "password_key"
    lateinit var sharedpreferences: SharedPreferences

    var user: String = ""
    var password: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        //val sharedPrefFile = "kotlinsharedpreference"
        supportActionBar?.hide()
        var u:Int = 1
        var log =findViewById<Button>(R.id.cirLoginButton)
        var eti = findViewById<EditText>(R.id.editTextName)
        var etp = findViewById<EditText>(R.id.editTextPassword)
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)



        // in shared prefs inside het string method

        // we are passing key value as EMAIL_KEY and

        // default value is

        // set to null if not present.

        user = sharedpreferences.getString(USER_KEY, null).toString()

        password = sharedpreferences.getString(PASSWORD_KEY, null).toString()

        log.setOnClickListener {

            if(etp.text.isBlank()|| eti.text.isBlank()){
                if(etp.text.isBlank()){
                    etp.setError("Please fill out password")
                    etp.requestFocus()
                }
                else if(eti.text.isBlank()){
                    eti.setError("Please fill out name")
                    eti.requestFocus()
                }
            }
            else {
                //var j=GlobalVariable.pass.indexOf(etp.text.toString())
                var j=check(eti.text.toString(),etp.text.toString())

            }

            }
        }


    private fun displayerror() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage("Username or password is incorrect")
        builder.setIcon(android.R.drawable.ic_dialog_alert)
        builder.setPositiveButton("Ok"){dialogInterface, which ->
        }

        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
    private fun check(userName: String,password:String) {

        var database = FirebaseDatabase.getInstance().getReference("users/${userName.toString()}")

        database.child("Userdetails").get().addOnSuccessListener {
            if (it.exists()){
                val pass = it.child("password").value.toString()
                if(pass.equals(password)){
                    val editor: SharedPreferences.Editor = sharedpreferences.edit()
                    editor.putString(USER_KEY, userName)
                    editor.putString(PASSWORD_KEY, password)
                    editor.apply()
                    val intent = Intent(this, ViewDetailsActivity::class.java)
                    startActivity(intent)
                    finish()
                    //Toast.makeText(this,"correct",Toast.LENGTH_SHORT).show()
                }
                else{
                    //i=0
                    //Toast.makeText(this,"icorrect",Toast.LENGTH_SHORT).show()
                    displayerror()
                }
            }
            else{
                displayerror()
            }
        }

    }

    fun onRegClick(view: View) {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }

    override fun onStart() {
        super.onStart()
        if (!sharedpreferences.getString(USER_KEY, null).isNullOrBlank()) {
            val i = Intent(this, ViewDetailsActivity::class.java)
            startActivity(i)
        }
    }
}


