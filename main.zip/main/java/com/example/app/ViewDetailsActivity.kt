package com.example.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.media.Image
import android.os.Bundle
import android.text.Layout
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ViewDetailsActivity : AppCompatActivity() {
    val SHARED_PREFS = "shared_prefs"
    val USER_KEY = "user_key"
    val PASSWORD_KEY = "password_key"
    lateinit var sharedpreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_details)
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        var user: String
        user = sharedpreferences.getString(USER_KEY, null).toString()
        var d: FirebaseDatabase = FirebaseDatabase.getInstance()
        var node: DatabaseReference =d.getReference("users/${sharedpreferences.getString(USER_KEY, null).toString()}")
        node.get().addOnSuccessListener {
            if (it.exists()) {
                findViewById<TextView>(R.id.eTbio).setText(it.child("personal/bio").value.toString())
                findViewById<TextView>(R.id.eTbio).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTco).setText(it.child("personal/contact").value.toString())
                findViewById<TextView>(R.id.eTco).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTname).setText(it.child("personal/fullname").value.toString())
                findViewById<TextView>(R.id.eTname).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTgender).setText(it.child("personal/gender").value.toString())
                findViewById<TextView>(R.id.eTgender).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTho).setText(it.child("personal/hobbies").value.toString())
                findViewById<TextView>(R.id.eTho).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTclassX).setText(it.child("educational/classX").value.toString())
                findViewById<TextView>(R.id.eTclassX).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTclassXII).setText(it.child("educational/classXII").value.toString())
                findViewById<TextView>(R.id.eTclassXII).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.gradclg).setText(it.child("educational/gradclg").value.toString())
                findViewById<TextView>(R.id.gradclg).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTgradtype).setText(it.child("educational/gradtype").value.toString())
                findViewById<TextView>(R.id.eTgradtype).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTsal).setText(it.child("financial/salary").value.toString())
                findViewById<TextView>(R.id.eTsal).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTctc).setText(it.child("financial/ctc").value.toString())
                findViewById<TextView>(R.id.eTctc).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTit).setText(it.child("financial/incometax").value.toString())
                findViewById<TextView>(R.id.eTit).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTdad).setText(it.child("family/fathername").value.toString())
                findViewById<TextView>(R.id.eTdad).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTmom).setText(it.child("family/mothername").value.toString())
                findViewById<TextView>(R.id.eTmom).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTsi).setText(it.child("family/siblings").value.toString())
                findViewById<TextView>(R.id.eTsi).setTextColor(Color.parseColor("#1E0E06"))
                findViewById<TextView>(R.id.eTsp).setText(it.child("family/spousename").value.toString())
                findViewById<TextView>(R.id.eTsp).setTextColor(Color.parseColor("#1E0E06"))

            }
        }
        findViewById<TextView>(R.id.logout).setOnClickListener {
            val editor = sharedpreferences.edit()
            editor.clear()
            editor.apply()
            val i = Intent(this, LoginActivity::class.java)
            startActivity(i)
            finish()
        }

        findViewById<ImageButton>(R.id.expandfi).setOnClickListener {
            if(findViewById<View>(R.id.filayout).visibility=== View.VISIBLE){
                findViewById<ImageButton>(R.id.expandfi).setImageResource(R.drawable.ic_baseline_expand_more_24)
                findViewById<View>(R.id.filayout).visibility= View.GONE
            }
            else{
                findViewById<ImageButton>(R.id.expandfi).setImageResource(R.drawable.ic_baseline_expand_less_24)
                findViewById<View>(R.id.filayout).visibility= View.VISIBLE
            }

        }
        findViewById<ImageButton>(R.id.expandpe).setOnClickListener {
            if(findViewById<View>(R.id.personallayout).visibility=== View.VISIBLE){
                findViewById<ImageButton>(R.id.expandpe).setImageResource(R.drawable.ic_baseline_expand_more_24)
                findViewById<View>(R.id.personallayout).visibility= View.GONE
            }
            else{
                findViewById<ImageButton>(R.id.expandpe).setImageResource(R.drawable.ic_baseline_expand_less_24)
                findViewById<View>(R.id.personallayout).visibility= View.VISIBLE
            }

        }
        findViewById<ImageButton>(R.id.expandfam).setOnClickListener {
            if(findViewById<View>(R.id.familylayout).visibility=== View.VISIBLE){
                findViewById<ImageButton>(R.id.expandfam).setImageResource(R.drawable.ic_baseline_expand_more_24)
                findViewById<View>(R.id.familylayout).visibility= View.GONE
            }
            else{
                findViewById<ImageButton>(R.id.expandfam).setImageResource(R.drawable.ic_baseline_expand_less_24)
                findViewById<View>(R.id.familylayout).visibility= View.VISIBLE
            }

        }
        findViewById<ImageButton>(R.id.expandedu).setOnClickListener {
            if(findViewById<View>(R.id.edulayout).visibility=== View.VISIBLE){
                findViewById<ImageButton>(R.id.expandedu).setImageResource(R.drawable.ic_baseline_expand_more_24)
                findViewById<View>(R.id.edulayout).visibility= View.GONE
            }
            else{
                findViewById<ImageButton>(R.id.expandedu).setImageResource(R.drawable.ic_baseline_expand_less_24)
                findViewById<View>(R.id.edulayout).visibility= View.VISIBLE
            }

        }

    }

}