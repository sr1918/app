package com.example.app

class Educational {
    lateinit var classX:String
    lateinit var classXII:String
    lateinit var gradtype:String
    lateinit var gradclg:String

    constructor(classX: String, classXII: String, gradclg: String,gradtype: String) {
        this.classX = classX
        this.classXII = classXII
        this.gradtype = gradtype
        this.gradclg = gradclg
    }
}