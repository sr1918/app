package com.example.app

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [EducationalDetails.newInstance] factory method to
 * create an instance of this fragment.
 */
@Suppress("UNREACHABLE_CODE")
class EducationalDetails : Fragment() {
    // TODO: Rename and change types of parameters
    private lateinit var seterrorclassX: TextView
    private lateinit var seterrorclassXII: TextView
    private lateinit var seterrorgradclg: TextView
    private var isvalidclassX=false
    private var isvalidclassXII=false
    private var isvalidgradclg=false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_educational_details, container, false)
        view.findViewById<EditText>(R.id.eTclassX).addTextChangedListener(textWatcher)
        view.findViewById<TextView>(R.id.validclassX).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<TextView>(R.id.validclassXII).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<TextView>(R.id.validgradclg).setTextColor(Color.parseColor("#FF0000"))
        view.findViewById<EditText>(R.id.eTclassXII).addTextChangedListener(textWatcher1)
        view.findViewById<EditText>(R.id.gradclg).addTextChangedListener(textWatcher2)
        seterrorclassX=view.findViewById<TextView>(R.id.validclassX)
        seterrorclassXII=view.findViewById<TextView>(R.id.validclassXII)
        seterrorgradclg=view.findViewById<TextView>(R.id.validgradclg)
        val viewpager=activity?.findViewById<ViewPager2>(R.id.viewpager2)
        val next=view?.findViewById<Button>(R.id.next2)
        next?.setOnClickListener {

        }
        view?.findViewById<Button>(R.id.prev2)?.setOnClickListener {
            val viewpager=activity?.findViewById<ViewPager2>(R.id.viewpager2)
            viewpager?.currentItem=0

        }
        view?.findViewById<Button>(R.id.next2)?.setOnClickListener {
            //  var d:DisplayDetailsActivity=DisplayDetailsActivity()
            var c=view.findViewById<Spinner>(R.id.spinner1).selectedItem.toString()
            if(isvalid(view.findViewById<EditText>(R.id.eTclassX).text.toString(),
                    view.findViewById<EditText>(R.id.eTclassXII).text.toString(),
                    view.findViewById<EditText>(R.id.gradclg).text.toString())) {
                saveFireStore(
                    view.findViewById<EditText>(R.id.eTclassX).text.toString(),
                    view.findViewById<EditText>(R.id.eTclassXII).text.toString(),
                    view.findViewById<EditText>(R.id.gradclg).text.toString(),
                    c
                )
                viewpager?.currentItem=2
            }
        }
        return view
    }
    val textWatcher2 = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorgradclg.setText("Field can't be empty")
                seterrorgradclg.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorgradclg.setText("Perfect")
                seterrorgradclg.setTextColor(Color.parseColor("#28DC30"))

            }
        }
    }
    val textWatcher = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorclassX.setText("Field can't be empty")
                seterrorclassX.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorclassX.setText("Perfect")
                seterrorclassX.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }
    val textWatcher1 = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if(s?.length==0){
                seterrorclassXII.setText("Field can't be empty")
                seterrorclassXII.setTextColor(Color.parseColor("#FF0000"))
            }
            else{
                seterrorclassXII.setText("Perfect")
                seterrorclassXII.setTextColor(Color.parseColor("#28DC30"))
            }
        }
    }

    fun saveFireStore(classX: String, classXII: String, gradclg: String,gradtype:String) {
        var name:String=GlobalVariable.name
        var userobject:Educational= Educational(classX,classXII,gradclg,gradtype)
        var d: FirebaseDatabase = FirebaseDatabase.getInstance()
        var node: DatabaseReference =d.getReference("users/$name")
        node.child("educational").setValue(userobject)
    }
    fun isvalid(classX:String,classXII: String,gradclg: String):Boolean{
        var isvalidclassX=classX.isNotEmpty()
        var isvalidclassXII=classXII.isNotEmpty()
        var isvalidgradclg=gradclg.isNotEmpty()
        return isvalidclassX&&isvalidclassXII&&isvalidgradclg
    }
}